package com.ark.newark_phone;

import java.net.Socket;

/**
 * Created by a1314 on 15/1/15.
 */
public class G {

    public static byte[] buffer;
    public static Socket socket = null;
    public static int isnull = 0;
}
