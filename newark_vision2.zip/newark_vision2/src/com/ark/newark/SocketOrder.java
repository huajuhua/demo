package com.ark.newark;

import java.io.IOException;
import java.net.Socket;

/**
 * Created by a1314 on 15/6/5.
 */
public class SocketOrder {

    //查询
    public static void order_query(Socket socket) {
        byte[] buffer_control = new byte[12];
        buffer_control[0] = (byte) 1;
        buffer_control[1] = (byte) 0;
        buffer_control[2] = (byte) 0;
        buffer_control[3] = (byte) 0;
        buffer_control[4] = (byte) 0;
        buffer_control[5] = (byte) 10;
        buffer_control[6] = (byte) 0;
        buffer_control[7] = (byte) 0;
        buffer_control[8] = (byte) 0;
        buffer_control[9] = (byte) 0;
        buffer_control[10] = (byte) 0;
        buffer_control[11] = (byte) 0;


        try {
            socket.getOutputStream().write(buffer_control);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //返回心跳数据
    public static void order_heart(Socket socket ,byte[] buffer) {
        try {

            socket.getOutputStream().write(buffer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
