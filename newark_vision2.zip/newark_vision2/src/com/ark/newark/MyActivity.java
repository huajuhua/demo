package com.ark.newark;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.media.Image;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.*;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.xm.ChnInfo;
import com.xm.DevInfo;
import com.xm.MyConfig;
import com.xm.NetSdk;
import com.xm.video.MySurfaceView;
import org.w3c.dom.Text;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;

public class MyActivity extends Activity implements View.OnClickListener{
    /**
     * Called when the activity is first created.
     */
    private ImageView emer,window1,wind_img,window1_bg,window2,window2_bg,window3,window3_bg,window4,window4_bg,
            light1,light2,window1_up,window2_up,window3_up,window4_up,door,shuifa_img,
            window1_down,window2_down,window3_down,window4_down,escape_on,escape_off,escape_chuanglian_img;
    private TextView wendu_txt,shidu_txt,qiya_txt,oxy_txt,oxy_day,oxy_day_day,water_h,water_h_h;
    private OxyView oxyvalue1;
    private WaterView watervalue1;
    private Battary battary1;
    private Typeface face;
    private int count = 1;
    private Rotate3dAnimation rotation1;
    private boolean lihgt1_bool = false;
    private boolean lihgt2_bool = true;
    private boolean window1_bool = false;
    private boolean window2_bool = false;
    private boolean window3_bool = false;
    private boolean window4_bool = false;
    private boolean wind_img_bool = false;
    private boolean door_bool = false;
    private boolean escape_chuanglian_bool = false;
    private boolean shuifa_bool = false;
    private android.os.Handler datahandler;
    private Socket datasocket = null;
    private boolean video1_bool;
    private boolean video2_bool;
    private boolean video3_bool;
    private boolean video4_bool;
    private NetSdk mNetSdk = null;
    private WndsHolder mWndsHolder;
    private long mloginid1 = 0;
    private long[] mplayhandle1;
    private long mloginid2 = 0;
    private long[] mplayhandle2;
    private long mloginid3 = 0;
    private long[] mplayhandle3;
    private long mloginid4 = 0;
    private long[] mplayhandle4;
    private int mSocketStyle = MyConfig.SocketStyle.TCPSOCKET;
    private int mWndSelected = 0;
    private SharedPreferences mySharedPreferences;
    private String isbund = "false";
    private boolean isconnect;
    private android.os.Handler authhandler;
    private ImageView emer_bg;
    private String wendu,shidu,qiya,dianchi,kyangqi,shuiwei,yyangqi;
    private boolean vv1_bool = false;
    private boolean vv2_bool = false;
    private boolean vv3_bool = false;
    private boolean vv4_bool = false;
    private boolean video1_ison = false;
    private boolean video2_ison = false;
    private boolean video3_ison = false;
    private boolean video4_ison = false;
    private boolean emer_bool = false;
    private boolean emer_bool_soft = false;
    private boolean emer_img_bool = false;
    private Animation animation,hyperspaceJumpAnimation_wind;
    private Dialog dialog;
    private boolean wind_bool = false;
    private long timecha;
    private long lasttime = 0;
    private boolean isconnectnow = false;
    private Dialog dialog_shui;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        uiti();
        getLocalMacAddress();
        mNetSdk = NetSdk.getInstance();

        dialog_shui = dialog_shui();

//        Animation operatingAnim = AnimationUtils.loadAnimation(this, R.anim.tip);
//        LinearInterpolator lin = new LinearInterpolator();
//        operatingAnim.setInterpolator(lin);
//
//        wind_img.startAnimation(operatingAnim);

        authhandler = new android.os.Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if (msg.what == 0) {
                    dialog(msg.getData().getByteArray("databuffer"));
                }else if (msg.what == 1){
                    byte[] buffer = msg.getData().getByteArray("databuffer");
                    kyangqi = String.valueOf(Integer.valueOf(buffer[12])) +"."+ String.valueOf(buffer[13]).substring(0,1);
                    yyangqi = String.valueOf(bigByteToShort(buffer, 14));
                    wendu = String.valueOf(Integer.valueOf(buffer[16])) + "."+String.valueOf(buffer[17]).substring(0,1);
                    shidu = String.valueOf(Integer.valueOf(buffer[18])) + "."+String.valueOf(buffer[19]).substring(0,1);
//                    dianchi = String.valueOf(Integer.valueOf(buffer[20])) + "."+String.valueOf(buffer[21]).substring(0,1);
                    shuiwei = String.valueOf(Integer.valueOf(buffer[22])) +"."+ String.valueOf(buffer[23]).substring(0,1);
                    dianchi = String.valueOf(bigByteToShort(buffer,20));
                    qiya = String.valueOf(bigByteToShort(buffer, 26));
                    if (buffer[43] == 1){
                       if (dialog_shui.isShowing()){

                       }else {
                           new Thread(new Runnable() {
                               @Override
                               public void run() {
                                   try {
                                       Thread.sleep(3000);
                                   } catch (InterruptedException e) {
                                       e.printStackTrace();
                                   }
                                   Message msg = new Message();
                                   msg.what = 3;
                                   authhandler.sendMessage(msg);
                               }
                           }).start();
//                           dialog_shui.show();
                       }
                    }

                    Log.d("",shuiwei+"--------------3-----------------------"+yyangqi);


                    wendu_txt.setText(wendu);
                    shidu_txt.setText(shidu);
                    qiya_txt.setText(qiya);
                    oxy_txt.setText(kyangqi);
                    battary1.setbattaryValue(Integer.valueOf(dianchi));
                    if (Integer.valueOf(yyangqi) > 1000){
                        oxyvalue1.setoxyValue(Integer.valueOf(yyangqi));
                    }else {
                        oxyvalue1.setoxyValue(1000);
                    }
                    watervalue1.setwaterValue(Double.valueOf(shuiwei));
                    water_h.setText(shuiwei);

                    if (buffer[30] == 1) {//通风换气
                        wind_bool = true;
//                        wind_img.setBackgroundResource(R.drawable.wind_on);
                        if (hyperspaceJumpAnimation_wind == null) {
                            hyperspaceJumpAnimation_wind = AnimationUtils.loadAnimation(MyActivity.this,R.anim.loading);
                            wind_img.startAnimation(hyperspaceJumpAnimation_wind);
                        }
                    } else {
                        wind_bool = false;
//                        wind_img.setBackgroundResource(R.drawable.wind_off);
                        wind_img.clearAnimation();
                        hyperspaceJumpAnimation_wind = null;
                    }
                    if (buffer[31] == 1){//软件紧急模式
                        emer_bool_soft = true;
                    }else {
                        emer_bool_soft = false;
                    }
                    if (buffer[40] == 1) { //手动紧急模式
                        emer_bool = true;
                    } else {
                        emer_bool = false;
                    }
                    if (emer_bool) {
                        emer_bg.setVisibility(View.VISIBLE);
                        emer_img_bool = true;
                        emerui(true);
                        if (animation == null) {
                            animation = new AlphaAnimation(0.3f, 1.0f);
                            animation.setDuration(600);
                            animation.setRepeatCount(Integer.MAX_VALUE);
                            animation.setRepeatMode(Animation.REVERSE);
                            emer_bg.startAnimation(animation);
                        }

                    } else {
                        if (dialog != null) {
                            dialog.dismiss();
                            dialog = null;
                            order_s(18);
                            emerui(false);
                        }

                        if (emer_bool_soft) {
                            emer_bg.setVisibility(View.VISIBLE);
                            emer_img_bool = true;
                            emerui(true);
                            if (animation == null) {
                                animation = new AlphaAnimation(0.3f, 1.0f);
                                animation.setDuration(600);
                                animation.setRepeatCount(Integer.MAX_VALUE);
                                animation.setRepeatMode(Animation.REVERSE);
                                emer_bg.startAnimation(animation);
                            }
                        } else {
                            emerui(false);
                            emer_img_bool = false;
                            emer_bg.clearAnimation();
                            animation = null;
                            emer_bg.setVisibility(View.INVISIBLE);
                        }

                    }



                }else if (msg.what == 2){
                    Toast.makeText(MyActivity.this,"网络断开，正在自动重连",Toast.LENGTH_LONG).show();
                }else if (msg.what == 3){
                    dialog_shui.show();
                }
            }

        };



        new Thread(runnable).start();

        new Thread(new Runnable() {

                @Override
                public void run() {
                    // TODO Auto-generated method stub
                    for (int i = 0; i < Integer.MAX_VALUE; i++) {
                        video1_bool = startPing("192.168.1.50");
//                        Log.d("","--------------------d--------------------------"+video1_bool);
                        if (video1_bool) {
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            break;
                        }
                    }
                    if (video1_bool) {
                        Stop(mWndsHolder.vv1, mplayhandle1);
                        DevInfo devInfo = new DevInfo();
                        devInfo.Ip = "192.168.1.50";
                        devInfo.TCPPort = 34567;
                        devInfo.UserName = "admin".getBytes();
                        devInfo.PassWord = "";
                        mloginid1 = mNetSdk.onLoginDev(mWndSelected, devInfo, null, mSocketStyle);
                        mplayhandle1 = new long[devInfo.ChanNum];
                        mNetSdk.SetupAlarmChan(mloginid1);
                        mNetSdk.SetAlarmMessageCallBack();
                        ChnInfo chnInfo = new ChnInfo();
                        chnInfo.ChannelNo = 0;
                        long playhandle1 = mNetSdk.onRealPlay(0, mloginid1, chnInfo);

                        mWndsHolder.vv1.onPlay();
                        mNetSdk.setDataCallback(playhandle1);
                        mNetSdk.setReceiveCompleteVData(0, true);
                    }

                }
            }).start();

            new Thread(new Runnable() {

                @Override
                public void run() {
                    // TODO Auto-generated method stub
                    for (int i = 0; i < Integer.MAX_VALUE; i++) {
                        video2_bool = startPing("192.168.1.51");
                        if (video2_bool) {
                            try {
                                Thread.sleep(2000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            break;
                        }
                    }
                    if (video2_bool) {
                        Stop(mWndsHolder.vv2, mplayhandle2);
                        DevInfo devInfo = new DevInfo();
                        devInfo.Ip = "192.168.1.51";
                        devInfo.TCPPort = 34567;
                        devInfo.UserName = "admin".getBytes();
                        devInfo.PassWord = "";
                        mloginid2 = mNetSdk.onLoginDev(mWndSelected, devInfo, null, mSocketStyle);
                        mplayhandle2 = new long[devInfo.ChanNum];
                        mNetSdk.SetupAlarmChan(mloginid2);
                        mNetSdk.SetAlarmMessageCallBack();
                        ChnInfo chnInfo = new ChnInfo();
                        chnInfo.ChannelNo = 0;
                        long playhandle2 = mNetSdk.onRealPlay(1, mloginid2, chnInfo);

                        mWndsHolder.vv2.onPlay();
                        mNetSdk.setDataCallback(playhandle2);
                        mNetSdk.setReceiveCompleteVData(0, true);
                    }

                }
            }).start();

            new Thread(new Runnable() {

                @Override
                public void run() {
                    // TODO Auto-generated method stub
                    for (int i = 0; i < Integer.MAX_VALUE; i++) {
                        video3_bool = startPing("192.168.1.52");
                        if (video3_bool) {
                            try {
                                Thread.sleep(2000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            break;
                        }
                    }
                        if (video3_bool) {
                            Stop(mWndsHolder.vv3, mplayhandle3);
                            DevInfo devInfo = new DevInfo();
                            devInfo.Ip = "192.168.1.52";
                            devInfo.TCPPort = 34567;
                            devInfo.UserName = "admin".getBytes();
                            devInfo.PassWord = "";
                            mloginid3 = mNetSdk.onLoginDev(mWndSelected, devInfo, null, mSocketStyle);
                            mplayhandle3 = new long[devInfo.ChanNum];
                            mNetSdk.SetupAlarmChan(mloginid3);
                            mNetSdk.SetAlarmMessageCallBack();
                            ChnInfo chnInfo = new ChnInfo();
                            chnInfo.ChannelNo = 0;
                            long playhandle3 = mNetSdk.onRealPlay(2, mloginid3, chnInfo);

                            mWndsHolder.vv3.onPlay();
                            mNetSdk.setDataCallback(playhandle3);
                            mNetSdk.setReceiveCompleteVData(0, true);
                        }
                    }
            }).start();

            new Thread(new Runnable() {

            @Override
            public void run() {
                // TODO Auto-generated method stub
                for (int i = 0; i < Integer.MAX_VALUE; i++) {
                    video1_bool = startPing("192.168.1.53");
                    if (video1_bool) {
                        try {
                            Thread.sleep(2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        break;
                    }
                }
                if (video1_bool) {
                    Stop(mWndsHolder.vv4, mplayhandle4);
                    DevInfo devInfo = new DevInfo();
                    devInfo.Ip = "192.168.1.53";
                    devInfo.TCPPort = 34567;
                    devInfo.UserName = "admin".getBytes();
                    devInfo.PassWord = "";
                    mloginid4 = mNetSdk.onLoginDev(mWndSelected, devInfo, null, mSocketStyle);
                    mplayhandle4 = new long[devInfo.ChanNum];
                    mNetSdk.SetupAlarmChan(mloginid4);
                    mNetSdk.SetAlarmMessageCallBack();
                    ChnInfo chnInfo = new ChnInfo();
                    chnInfo.ChannelNo = 0;
                    long playhandle4 = mNetSdk.onRealPlay(3, mloginid4, chnInfo);

                    mWndsHolder.vv4.onPlay();
                    mNetSdk.setDataCallback(playhandle4);
                    mNetSdk.setReceiveCompleteVData(0, true);

                }

                }
                }).start();
            }

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                {
                    newconnect();
                }
            }
        };

    private void newconnect() {

        try {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            datasocket = null;
            datasocket = new Socket("192.168.1.134", 7777);//数据
//                                login(datasocket);
            for (int i = 0; i < Integer.MAX_VALUE; i++) {
                if (datasocket != null) {
                    if (lasttime != 0) {
                        timecha = System.currentTimeMillis() - lasttime;
                        Log.d("", "----------------------timecha--------------" + timecha);
                        if (isconnectnow) {
                            if (timecha < 3000) {
                                isconnectnow = false;
                            }
                        } else {
                            if (timecha > 3000) {
                                isconnectnow = true;
                                datasocket = null;
                                Message msg = new Message();
                                msg.what = 2;
                                authhandler.sendMessage(msg);
                                newconnect();
                            } else {
                                isconnectnow = false;
                            }

                        }

                    }
                    answer();
                }
            }
            }catch(IOException e){
                isconnectnow = true;
                datasocket = null;
                Message msg = new Message();
                msg.what = 2;
                authhandler.sendMessage(msg);
                newconnect();
                e.printStackTrace();
            }
    }


    private void uiti(){
        face = Typeface.createFromAsset(this.getResources().getAssets(), "Transformers.ttf");
        mWndsHolder = new WndsHolder();
        light1 = (ImageView) findViewById(R.id.light1);
        light2 = (ImageView) findViewById(R.id.light2);
        window1 = (ImageView) findViewById(R.id.window1);
        window1_bg = (ImageView) findViewById(R.id.window1_bg);
        window2 = (ImageView) findViewById(R.id.window2);
        window2_bg = (ImageView) findViewById(R.id.window2_bg);
        window3 = (ImageView) findViewById(R.id.window3);
        window3_bg = (ImageView) findViewById(R.id.window3_bg);
        window4 = (ImageView) findViewById(R.id.window4);
        window4_bg = (ImageView) findViewById(R.id.window4_bg);
        wind_img = (ImageView) findViewById(R.id.wind_img);
        window1_up = (ImageView) findViewById(R.id.window1_up);
        window2_up = (ImageView) findViewById(R.id.window2_up);
        window3_up = (ImageView) findViewById(R.id.window3_up);
        window4_up = (ImageView) findViewById(R.id.window4_up);
        window1_down = (ImageView) findViewById(R.id.window1_down);
        window2_down = (ImageView) findViewById(R.id.window2_down);
        window3_down = (ImageView) findViewById(R.id.window3_down);
        window4_down = (ImageView) findViewById(R.id.window4_down);
        battary1 = (com.ark.newark.Battary) findViewById(R.id.battary1);
        emer = (ImageView) findViewById(R.id.emer);
        emer_bg = (ImageView) findViewById(R.id.emer_bg);
        wendu_txt = (TextView) findViewById(R.id.wendu_txt);
        shidu_txt = (TextView) findViewById(R.id.shidu_txt);
        qiya_txt = (TextView) findViewById(R.id.qiya_txt);
        oxy_txt = (TextView) findViewById(R.id.oxy_txt);
//        oxy_day = (TextView) findViewById(R.id.oxy_day);
//        oxy_day_day = (TextView) findViewById(R.id.oxy_day_day);
        water_h = (TextView) findViewById(R.id.water_h);
        water_h_h = (TextView) findViewById(R.id.water_h_h);
        oxyvalue1 = (OxyView) findViewById(R.id.oxyvalue1);
        door = (ImageView) findViewById(R.id.door);
        escape_on = (ImageView) findViewById(R.id.escape_on);
        escape_off = (ImageView) findViewById(R.id.escape_off);
        escape_chuanglian_img = (ImageView) findViewById(R.id.escape_chuanglian_img);
        shuifa_img = (ImageView) findViewById(R.id.shuifa_img);
        water_h = (TextView) findViewById(R.id.water_h);
//        escape_off.setClickable(false);
        watervalue1 = (WaterView) findViewById(R.id.watervalue1);
        mWndsHolder.vv1 = (MySurfaceView) findViewById(R.id.vv1);
        mWndsHolder.vv2 = (MySurfaceView) findViewById(R.id.vv2);
        mWndsHolder.vv3 = (MySurfaceView) findViewById(R.id.vv3);
        mWndsHolder.vv4 = (MySurfaceView) findViewById(R.id.vv4);

        mWndsHolder.vv1.init(this, 0);
        mWndsHolder.vv2.init(this, 1);
        mWndsHolder.vv3.init(this, 2);
        mWndsHolder.vv4.init(this, 3);


        wendu_txt.setTypeface(face);
        shidu_txt.setTypeface(face);
        qiya_txt.setTypeface(face);
        oxy_txt.setTypeface(face);
//        oxy_day.setTypeface(face);
//        oxy_day_day.setTypeface(face);
        water_h.setTypeface(face);
        water_h_h.setTypeface(face);

        light1.setOnClickListener(this);
        light2.setOnClickListener(this);
        window1.setOnClickListener(this);
        window1_up.setOnClickListener(this);
        window2_up.setOnClickListener(this);
        window3_up.setOnClickListener(this);
        window4_up.setOnClickListener(this);
        window1_down.setOnClickListener(this);
        window2_down.setOnClickListener(this);
        window3_down.setOnClickListener(this);
        window4_down.setOnClickListener(this);
        wind_img.setOnClickListener(this);
        door.setOnClickListener(this);
        emer.setOnClickListener(this);
        escape_on.setOnClickListener(this);
        escape_off.setOnClickListener(this);
        escape_chuanglian_img.setOnClickListener(this);
        shuifa_img.setOnClickListener(this);

        mWndsHolder.vv1.setOnClickListener(this);
        mWndsHolder.vv2.setOnClickListener(this);
        mWndsHolder.vv3.setOnClickListener(this);
        mWndsHolder.vv4.setOnClickListener(this);

        BackgroundHelper.setBackgroundEffect(window1_up,R.drawable.window_up);
        BackgroundHelper.setBackgroundEffect(window1_down,R.drawable.window_down);
        BackgroundHelper.setBackgroundEffect(window2_up,R.drawable.window_up);
        BackgroundHelper.setBackgroundEffect(window2_down,R.drawable.window_down);
        BackgroundHelper.setBackgroundEffect(window3_up,R.drawable.window_up);
        BackgroundHelper.setBackgroundEffect(window3_down,R.drawable.window_down);
        BackgroundHelper.setBackgroundEffect(window4_up,R.drawable.window_up);
        BackgroundHelper.setBackgroundEffect(window4_down,R.drawable.window_down);
        BackgroundHelper.setBackgroundEffect(emer,R.drawable.emer);
        BackgroundHelper.setBackgroundEffect(light1,R.drawable.light_off);
        BackgroundHelper.setBackgroundEffect(light2,R.drawable.light_off);
        BackgroundHelper.setBackgroundEffect(door,R.drawable.door_off);
        BackgroundHelper.setBackgroundEffect(escape_on,R.drawable.escape_on);
        BackgroundHelper.setBackgroundEffect(escape_off,R.drawable.escape_off);
        BackgroundHelper.setBackgroundEffect(escape_chuanglian_img,R.drawable.set);
        BackgroundHelper.setBackgroundEffect(shuifa_img,R.drawable.ac_off);

//        applyRotation(window1);
    }


    //3D翻转
    private Rotate3dAnimation applyRotation(ImageView view ) {
        // 计算中心点
        float centerX = view.getWidth() / 2.0f;
        float centerY = view.getHeight() / 2.0f;

        rotation1 = new Rotate3dAnimation(0, 360,
                centerX, centerY, 0, true);
        rotation1.setDuration(2000);
        rotation1.setFillAfter(true);
        rotation1.setRepeatCount(-1);
//        rotation.setInterpolator(new AccelerateInterpolator());
//        // 设置监听
//        rotation.setAnimationListener(new DisplayNextView());
        return rotation1;
//        applyRotation(0, 90);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.escape_chuanglian_img:
                if (escape_chuanglian_bool){
                    order(34, 0, 1);
                    escape_chuanglian_bool = false;
                }else {
                    order(34, 0, 0);
                    escape_chuanglian_bool = true;
                }
                break;
            case R.id.shuifa_img:
                if (shuifa_bool){
                    order(19,0,1);
                    shuifa_bool = false;
                }else{
                    order(19,0,0);
                    shuifa_bool = true;
                }
                break;
            case R.id.light1:
                if (lihgt1_bool){
                    order(12, 0, 1);
//                    light1.setBackgroundResource(R.drawable.light_on);
                    lihgt1_bool = false;
                }else {
                    order(12, 0, 0);
//                    light1.setBackgroundResource(R.drawable.light_off);
                    lihgt1_bool = true;
                }
                break;
            case R.id.light2:
                if (lihgt2_bool){
                    order(12, 1, 1);
//                    light2.setBackgroundResource(R.drawable.light_on);
                    lihgt2_bool = false;
                }else {
                    order(12, 1, 0);
//                    light2.setBackgroundResource(R.drawable.light_off);
                    lihgt2_bool = true;
                }
                break;
            case R.id.window1:
                if (window1_bool){
//                    window1.clearAnimation();
                    window1_bg.setBackgroundResource(R.drawable.window_off_bg);
                    window1.setBackgroundResource(R.drawable.window_off);
                    window1_bool = false;
                }else {
                    window1_bg.setBackgroundResource(R.drawable.window_on_bg);
                    window1.setBackgroundResource(R.drawable.window_on);
//                    window1.startAnimation(applyRotation(window1));
                    window1_bool = true;
                }
                break;
            case R.id.window1_up:
                order(13, 0, 1);
//                window1.clearAnimation();
//                window1_bg.setBackgroundResource(R.drawable.window_on_bg);
//                window1.setBackgroundResource(R.drawable.window_on);
//                window1.startAnimation(applyRotation(window1));
                break;
            case R.id.window1_down:
                order(13, 0, 0);
//                window1.clearAnimation();
//                window1_bg.setBackgroundResource(R.drawable.window_off_bg);
//                window1.setBackgroundResource(R.drawable.window_off);
//                window1.startAnimation(applyRotation(window1));
                break;
            case R.id.window2_up:
                order(13, 1, 1);
//                window2.clearAnimation();
//                window2_bg.setBackgroundResource(R.drawable.window_on_bg);
//                window2.setBackgroundResource(R.drawable.window_on);
//                window2.startAnimation(applyRotation(window2));
                break;
            case R.id.window2_down:
                order(13, 1, 0);
//                window2.clearAnimation();
//                window2_bg.setBackgroundResource(R.drawable.window_off_bg);
//                window2.setBackgroundResource(R.drawable.window_off);
//                window2.startAnimation(applyRotation(window2));
                break;
            case R.id.window3_up:
                order(13, 2, 1);
//                window3.clearAnimation();
//                window3_bg.setBackgroundResource(R.drawable.window_on_bg);
//                window3.setBackgroundResource(R.drawable.window_on);
//                window3.startAnimation(applyRotation(window3));
                break;
            case R.id.window3_down:
                order(13, 2, 0);
//                window3.clearAnimation();
//                window3_bg.setBackgroundResource(R.drawable.window_off_bg);
//                window3.setBackgroundResource(R.drawable.window_off);
//                window3.startAnimation(applyRotation(window3));
                break;
            case R.id.window4_up:
                order(13, 3, 1);
//                window4.clearAnimation();
//                window4_bg.setBackgroundResource(R.drawable.window_on_bg);
//                window4.setBackgroundResource(R.drawable.window_on);
//                window4.startAnimation(applyRotation(window4));
                break;
            case R.id.window4_down:
                order(13, 3, 0);
//                window4.clearAnimation();
//                window4_bg.setBackgroundResource(R.drawable.window_off_bg);
//                window4.setBackgroundResource(R.drawable.window_off);
//                window4.startAnimation(applyRotation(window4));
                break;
            case R.id.wind_img:
                if (wind_img_bool){
                    order(15, 0, 1);
                    wind_img.setBackgroundResource(R.drawable.wind_off);
                    if (hyperspaceJumpAnimation_wind == null) {
                        hyperspaceJumpAnimation_wind = AnimationUtils.loadAnimation(MyActivity.this,R.anim.loading);
                        wind_img.startAnimation(hyperspaceJumpAnimation_wind);
                    }
                    wind_img_bool = false;
                }else{
                    order(15, 0, 0);
                    wind_img.setBackgroundResource(R.drawable.wind_off);
                    wind_img.clearAnimation();
                    wind_img_bool = true;
                    hyperspaceJumpAnimation_wind = null;
                }
                break;
            case R.id.door:
                if (door_bool){
                    order(14, 0, 1);
//                    door.setBackgroundResource(R.drawable.door_on);
                    door_bool = false;
                }else {
                    order(14, 0, 0);
//                    door.setBackgroundResource(R.drawable.door_on);
                    door_bool = true;
                }
                break;
            case R.id.escape_on:
                order(33, 0, 1);
                break;
            case R.id.escape_off:
                order(33, 0, 0);
                break;
            case R.id.emer:
                emerui(true);
                if (emer_img_bool) {
                    if (emer_bool) {
                        Log.d("", "----------------------------------3-----------------------");
                        dialog = dialog();
                        dialog.show();

                    } else if (emer_bool_soft) {
                        Log.d("", "----------------------------------4-----------------------");
                        order_s(18);//解除紧急模式
                        emer_bg.setVisibility(View.INVISIBLE);
                        emer_bg.clearAnimation();
                        animation = null;
                        emerui(false);
                    }

                } else {

                    Log.d("", "----------------------------------6-----------------------");
                    order_s(17);//进入紧急模式
                    emer_bg.setVisibility(View.VISIBLE);
                    animation = new AlphaAnimation(0.1f, 1.0f);
                    animation.setDuration(1000);
                    animation.setRepeatCount(Integer.MAX_VALUE);
                    animation.setRepeatMode(Animation.REVERSE);
                    emer_bg.startAnimation(animation);

                }
                break;
            case R.id.vv1:

                if (vv2_bool == false && vv3_bool == false && vv4_bool == false){
                    if (vv1_bool) {
                        vv1_bool = false;
                        mWndsHolder.vv2.setVisibility(View.VISIBLE);
                        mWndsHolder.vv3.setVisibility(View.VISIBLE);
                        mWndsHolder.vv4.setVisibility(View.VISIBLE);
                        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(382, 210);
                        params.setMargins(76, 143, 0, 0);
                        mWndsHolder.vv1.setLayoutParams(params);
                    } else {
                        vv1_bool = true;
                        mWndsHolder.vv2.setVisibility(View.INVISIBLE);
                        mWndsHolder.vv3.setVisibility(View.INVISIBLE);
                        mWndsHolder.vv4.setVisibility(View.INVISIBLE);
                        mWndsHolder.vv1.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                    }
                }

                break;
            case R.id.vv2:
                if (vv1_bool == false && vv3_bool == false && vv4_bool == false){
                    if (vv2_bool) {
                        mWndsHolder.vv1.setVisibility(View.VISIBLE);
                        mWndsHolder.vv3.setVisibility(View.VISIBLE);
                        mWndsHolder.vv4.setVisibility(View.VISIBLE);
                        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(382, 210);
                        params.setMargins(466, 143, 0, 0);
                        mWndsHolder.vv2.setLayoutParams(params);
                        vv2_bool = false;
                    } else {
                        mWndsHolder.vv1.setVisibility(View.INVISIBLE);
                        mWndsHolder.vv3.setVisibility(View.INVISIBLE);
                        mWndsHolder.vv4.setVisibility(View.INVISIBLE);
                        mWndsHolder.vv2.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                        vv2_bool = true;
                    }
                }
                break;
            case R.id.vv3:
                if (vv1_bool == false && vv2_bool == false && vv4_bool == false){
                    if (vv3_bool) {
                        mWndsHolder.vv1.setVisibility(View.VISIBLE);
                        mWndsHolder.vv2.setVisibility(View.VISIBLE);
                        mWndsHolder.vv4.setVisibility(View.VISIBLE);
                        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(382, 210);
                        params.setMargins(76, 356, 0, 0);
                        mWndsHolder.vv3.setLayoutParams(params);
                        vv3_bool = false;
                    } else {
                        mWndsHolder.vv1.setVisibility(View.INVISIBLE);
                        mWndsHolder.vv2.setVisibility(View.INVISIBLE);
                        mWndsHolder.vv4.setVisibility(View.INVISIBLE);
                        mWndsHolder.vv3.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                        vv3_bool = true;
                    }
                }
                break;
            case R.id.vv4:
                if (vv1_bool == false && vv2_bool == false && vv3_bool == false){
                    if (vv4_bool) {
                        mWndsHolder.vv1.setVisibility(View.VISIBLE);
                        mWndsHolder.vv2.setVisibility(View.VISIBLE);
                        mWndsHolder.vv3.setVisibility(View.VISIBLE);
                        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(382, 210);
                        params.setMargins(466, 356, 0, 0);
                        mWndsHolder.vv4.setLayoutParams(params);
                        vv4_bool = false;
                    } else {
                        mWndsHolder.vv1.setVisibility(View.INVISIBLE);
                        mWndsHolder.vv2.setVisibility(View.INVISIBLE);
                        mWndsHolder.vv3.setVisibility(View.INVISIBLE);
                        mWndsHolder.vv4.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                        vv4_bool = true;
                    }
                }
                break;
            default:

                break;
        }
    }

    //停止之前的监控
    private void Stop(MySurfaceView view, long[] mplayhandle) {
        mNetSdk.onStopAlarmMsg(true);
        view.onStop();
        if (mplayhandle != null) {
            if (mplayhandle.length > 0)
                mNetSdk.onStopRealPlay(mplayhandle[0]);
        }
    }

    //ping IP
    private boolean startPing(String ip) {
//        Log.e("Ping", "startPing...");
        boolean success = false;
        Process p = null;

        try {
            p = Runtime.getRuntime().exec("ping -c 1 -i 0.2 -W 1 " + ip);
            int status = p.waitFor();
            if (status == 0) {
                success = true;
            } else {
                success = false;
            }
        } catch (IOException e) {
            success = false;
        } catch (InterruptedException e) {
            success = false;
        } finally {
            p.destroy();
        }

        return success;
    }

    //获取MAC地址
    public String getLocalMacAddress() {
        WifiManager wifi = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifi.getConnectionInfo();
        byte[] mac = new byte[0];
        try {
            mac = info.getMacAddress().getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        try {
            String s_utf8 = new String(mac,"UTF-8").replace(":","");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return info.getMacAddress();
    }

    //获取设备型号
    public String getphone(){
        return  android.os.Build.MODEL;
    }


    //查询
    public static void order_query(Socket socket) {
        byte[] buffer_control = new byte[20];
        buffer_control[0] = (byte) 0;
        buffer_control[1] = (byte) 0;
        buffer_control[2] = (byte) 0;
        buffer_control[3] = (byte) 0;

        buffer_control[4] = (byte) 0;
        buffer_control[5] = (byte) 10;
        buffer_control[6] = (byte) 0;
        buffer_control[7] = (byte) 0;
        buffer_control[8] = (byte) 0;
        buffer_control[9] = (byte) 0;
        buffer_control[10] = (byte) 0;
        buffer_control[11] = (byte) 0;

        try {
            socket.getOutputStream().write(buffer_control);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    //登录
    private void login(Socket socket){
        byte[] buffer_login = new byte[32];

        byte[] buffer_login0 = new byte[12];
        byte[] buffer_login1 = new byte[4];
        byte[] buffer_login2 = new byte[15];
        byte[] buffer_login3 = new byte[1];

        buffer_login0[0] = (byte) 0;
        buffer_login0[1] = (byte) 0;
        buffer_login0[2] = (byte) 0;
        buffer_login0[3] = (byte) 0;
        buffer_login0[4] = (byte) 0;
        buffer_login0[5] = (byte) 2;
        buffer_login0[6] = (byte) 0;
        buffer_login0[7] = (byte) 20;
        buffer_login0[8] = (byte) 0;
        buffer_login0[9] = (byte) 0;
        buffer_login0[10] = (byte) 0;
        buffer_login0[11] = (byte) 0;

        buffer_login1[0] = (byte) 0;
        buffer_login1[1] = (byte) 0;
        buffer_login1[2] = (byte) 0;
        buffer_login1[3] = (byte) 0;

        buffer_login2 = ("000"+getLocalMacAddress()).getBytes();

        buffer_login3[0] = (byte) 0;

        System.arraycopy(buffer_login0,0,buffer_login,0,12);
        System.arraycopy(buffer_login1,0,buffer_login,12,4);
        System.arraycopy(buffer_login2,0,buffer_login,16,15);
        System.arraycopy(buffer_login3,0,buffer_login,31,1);

        try {
            socket.getOutputStream().write(buffer_login);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //申请绑定
    private void bund(Socket socket){

        byte[] buffer_bund = new byte[48];

        byte[] buffer_bund0 = new byte[12];
        byte[] buffer_bund1 = new byte[4];
        byte[] buffer_bund2 = new byte[15];
        byte[] buffer_bund3 = new byte[1];
        byte[] buffer_bund4 = new byte[15];
        byte[] buffer_bund5 = new byte[1];

        buffer_bund0[0] = (byte) 0;
        buffer_bund0[1] = (byte) 0;
        buffer_bund0[2] = (byte) 0;
        buffer_bund0[3] = (byte) 0;
        buffer_bund0[4] = (byte) 0;
        buffer_bund0[5] = (byte) 20;
        buffer_bund0[6] = (byte) 0;
        buffer_bund0[7] = (byte) 36;
        buffer_bund0[8] = (byte) 0;
        buffer_bund0[9] = (byte) 0;
        buffer_bund0[10] = (byte) 0;
        buffer_bund0[11] = (byte) 0;

        buffer_bund1[0] = (byte) 0;
        buffer_bund1[1] = (byte) 0;
        buffer_bund1[2] = (byte) 0;
        buffer_bund1[3] = (byte) 0;

        buffer_bund2 = ("000"+getLocalMacAddress()).getBytes();

        buffer_bund3[0] = (byte) 0;

        String phonesty = getphone();
        if (phonesty.length()>15){
            phonesty = phonesty.substring(0,15);
        }else if (phonesty.length() == 15){
            phonesty = phonesty;
        }else if (phonesty.length()<15){
            String a = null;
            for (int i=0;i<15-phonesty.length();i++){
                a = a+"0";
            }
            phonesty = a + phonesty;
        }
        buffer_bund4 = phonesty.getBytes();
        buffer_bund5[0] = (byte) 0;

        System.arraycopy(buffer_bund0,0,buffer_bund,0,12);
        System.arraycopy(buffer_bund1,0,buffer_bund,12,4);
        System.arraycopy(buffer_bund2,0,buffer_bund,16,15);
        System.arraycopy(buffer_bund3,0,buffer_bund,31,1);
        System.arraycopy(buffer_bund4,0,buffer_bund,32,15);
        System.arraycopy(buffer_bund5,0,buffer_bund,47,1);

        try {
            socket.getOutputStream().write(buffer_bund);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //绑定认证
    private void bundauth(Socket socket,byte[] bytes){

        byte[] buffer_bundauth = new byte[20];

        byte[] buffer_bundauth0 = new byte[12];
        byte[] buffer_bundauth1 = new byte[4];
        byte[] buffer_bundauth2 = new byte[4];

        buffer_bundauth0[0] = (byte) 0;
        buffer_bundauth0[1] = (byte) 0;
        buffer_bundauth0[2] = (byte) 0;
        buffer_bundauth0[3] = (byte) 0;
        buffer_bundauth0[4] = (byte) 0;
        buffer_bundauth0[5] = (byte) 23;
        buffer_bundauth0[6] = (byte) 0;
        buffer_bundauth0[7] = (byte) 8;
        buffer_bundauth0[8] = (byte) 0;
        buffer_bundauth0[9] = (byte) 0;
        buffer_bundauth0[10] = (byte) 0;
        buffer_bundauth0[11] = (byte) 0;

        buffer_bundauth1[0] = (byte) 0;
        buffer_bundauth1[1] = (byte) 1;
        buffer_bundauth1[2] = (byte) 0;
        buffer_bundauth1[3] = (byte) 0;

        System.arraycopy(buffer_bundauth0,0,buffer_bundauth,0,12);
        System.arraycopy(buffer_bundauth1,0,buffer_bundauth,12,4);
        System.arraycopy(bytes,0,buffer_bundauth,16,4);

        try {
            socket.getOutputStream().write(buffer_bundauth);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    //返回结果
    public void answer() {
        if (datasocket != null){
            byte[] bufferHead = new byte[12];
            byte[] bufferBody = null;
            try {
                InputStream basedata = datasocket.getInputStream();
                int readleng = basedata.read(bufferHead);
                if (readleng != -1) {
                    int num = bigByteToShort(bufferHead,6);
                    bufferBody = new byte[num+12];
                    basedata.read(bufferBody,12,num);
                    System.out.print("cmd:"+bufferHead[5] +" len:" + num);
                    for (int i=0;i<bufferHead.length;i++){
                        Log.d("", bufferHead.length+"------------head---================" + bufferHead[i]+"\n");
                    }

//                    System.arraycopy(bufferdata, 0, bufferheart, 0, readleng);
                    if (bufferHead[5] == 1) {
                        order_heart(bufferHead);
                        lasttime =  System.currentTimeMillis();
                        Log.d("","----------------------心跳时间--------------"+timecha);
                    }
                    if (bufferHead[5] == 21){//绑定返回值
                        Log.d("", "-----------------------" + "绑定成功");
                        if (bufferBody[13] == 0){
                            Log.d("", "-----------------------" + "重新成功");
                            login(datasocket);
                        }
                    }else if (bufferHead[5] == 3){//登录返回值
                        if (bufferBody[13] == 0){
                            Log.d("", "-------------9-----================" + "登录成功");
                        }else if (bufferBody[13] == 1){
                            Log.d("", "-----------------------" + "开始绑定");
                            bund(datasocket);
                        }
                    }else if (bufferHead[5] == 22){//绑定认证请求
                        Log.d("", "-----------------------" + "绑定");
                        Message msg = new Message();
                        msg.what = 0;
                        Bundle bundle = new Bundle();
                        bundle.putByteArray("databuffer", bufferBody);
                        msg.setData(bundle);
                        authhandler.sendMessage(msg);
                    }else if (bufferHead[5] == 11){//请求数据
                        for (int i=12;i<bufferBody.length;i++){
                          Log.d("", bufferBody.length - 12 +"------------body----================" + bufferBody[i]+"\n");
                       }
                        Message msg = new Message();
                        msg.what = 1;
                        Bundle bundle = new Bundle();
                        bundle.putByteArray("databuffer", bufferBody);
                        msg.setData(bundle);
                        authhandler.sendMessage(msg);
                    }else if (bufferHead[5] == 32){

                    }
                }

            }catch (IOException e) {
                e.printStackTrace();
            }

        }

//        byte[] bufferdata = new byte[1024];
//        byte[] bufferheart = new byte[12];
//        try {
//            InputStream basedata = datasocket.getInputStream();
//            int readleng = basedata.read(bufferdata);
//            if (readleng != -1){
//                if (bufferdata[5] == 21){//绑定返回值
//                    Log.d("", "-----------------------" + "绑定成功");
//                    if (bufferdata[13] == 0){
//                        Log.d("", "-----------------------" + "重新成功");
//                        login(datasocket);
//                    }
//                }else if (bufferdata[5] == 3){//登录返回值
//                    if (bufferdata[13] == 0){
//                        Log.d("", "-------------9-----================" + "登录成功");
//                    }else if (bufferdata[13] == 1){
//                        Log.d("", "-----------------------" + "开始绑定");
//                        bund(datasocket);
//                    }
//                }else if (bufferdata[5] == 22){//绑定认证请求
//                    Log.d("", "-----------------------" + "绑定");
//                    Message msg = new Message();
//                    msg.what = 0;
//                    Bundle bundle = new Bundle();
//                    bundle.putByteArray("databuffer", bufferdata);
//                    msg.setData(bundle);
//                    authhandler.sendMessage(msg);
//                }else if (bufferdata[5] == 11){//请求数据
//
//                    Message msg = new Message();
//                    msg.what = 1;
//                    Bundle bundle = new Bundle();
//                    bundle.putByteArray("databuffer", bufferdata);
//                    msg.setData(bundle);
//                    authhandler.sendMessage(msg);
//                }else if (bufferdata[5] == 32){
//
//                }
//            }
////            for (int i=0;i<readleng;i++){
////                Log.d("", readleng+"------------sdfsdfs----================" + bufferdata[i]+"\n"+bufferdata[5]);
////            }
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }

//    private static int bigByteToInt(byte[] bArr, int start) {
//        int m = ((bArr[start + 0] & 0xff) << 24) | ((bArr[start + 1] & 0xff) << 16) | ((bArr[start + 2] & 0xff) << 8) | (bArr[start + 3] & 0xff);
//        return m;
//    }
//
    private static short bigByteToShort(byte[] bArr, int start) {
        short m = (short) (((bArr[start + 0] & 0xff) << 8) | (bArr[start + 1] & 0xff));
        return m;
    }

    class WndsHolder {
        MySurfaceView vv1;
        MySurfaceView vv2;
        MySurfaceView vv3;
        MySurfaceView vv4;
    }

    //返回心跳数据
    public void order_heart(byte[] buffer) {
        try {
            if (datasocket != null){
                datasocket.getOutputStream().write(buffer);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //多组控制
    public void order(int order, int position, int isopen) {
        byte[] buffer_control = new byte[14];
        buffer_control[0] = (byte) 1;
        buffer_control[1] = (byte) 0;
        buffer_control[2] = (byte) 0;
        buffer_control[3] = (byte) 0;
        buffer_control[4] = (byte) 0;
        buffer_control[5] = (byte) order;
        buffer_control[6] = (byte) 0;
        buffer_control[7] = (byte) 2;
        buffer_control[8] = (byte) 0;
        buffer_control[9] = (byte) 0;
        buffer_control[10] = (byte) 0;
        buffer_control[11] = (byte) 0;

        buffer_control[12] = (byte) position;//第七颗灯,0xff开所有灯
        buffer_control[13] = (byte) isopen;//1:开灯，0:关灯
        Log.d("", datasocket+"----------------命令----------------" + order + "--" + position + "--" + isopen);
        try {
            if (datasocket != null) {
                datasocket.getOutputStream().write(buffer_control);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //单组控制
    public void order_s(int order) {
        byte[] buffer_control = new byte[12];
        buffer_control[0] = (byte) 1;
        buffer_control[1] = (byte) 0;
        buffer_control[2] = (byte) 0;
        buffer_control[3] = (byte) 0;
        buffer_control[4] = (byte) 0;
        buffer_control[5] = (byte) order;
        buffer_control[6] = (byte) 0;
        buffer_control[7] = (byte) 0;
        buffer_control[8] = (byte) 0;
        buffer_control[9] = (byte) 0;
        buffer_control[10] = (byte) 0;
        buffer_control[11] = (byte) 0;


        try {
            if (datasocket != null) {
                datasocket.getOutputStream().write(buffer_control);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void emerui(boolean bool){
        if (bool){
            window1_up.setEnabled(false);
            window2_up.setEnabled(false);
            window3_up.setEnabled(false);
            window4_up.setEnabled(false);
            window1_down.setEnabled(false);
            window2_down.setEnabled(false);
            window3_down.setEnabled(false);
            window4_down.setEnabled(false);
            wind_img.setEnabled(false);
            door.setEnabled(false);
            escape_on.setEnabled(false);
            escape_off.setEnabled(false);
            escape_chuanglian_img.setEnabled(false);
            shuifa_img.setEnabled(false);
        }else {
            window1_up.setEnabled(true);
            window2_up.setEnabled(true);
            window3_up.setEnabled(true);
            window4_up.setEnabled(true);
            window1_down.setEnabled(true);
            window2_down.setEnabled(true);
            window3_down.setEnabled(true);
            window4_down.setEnabled(true);
            wind_img.setEnabled(true);
            door.setEnabled(true);
            escape_on.setEnabled(true);
            escape_off.setEnabled(true);
            escape_chuanglian_img.setEnabled(true);
            shuifa_img.setEnabled(true);
        }
    }


    private Dialog dialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("请手动退出紧急模式")
                .setCancelable(false);
        AlertDialog alert = builder.create();

        return alert;
    }

    private Dialog dialog_shui() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("污水已满")
                .setCancelable(false)
                .setPositiveButton("确定",new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
        AlertDialog alert = builder.create();

        return alert;
    }

    protected void dialog(final byte[] buffer) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Authorization?")
                .setCancelable(false)
                .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        byte[] buffer_bundauthe = new byte[4];
                        System.arraycopy(buffer,16,buffer_bundauthe,0,4);
                        bundauth(datasocket,buffer_bundauthe);
                        dialog.cancel();
                    }
                })
                .setNegativeButton("no", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
}
